#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from pymongo import MongoClient
from bson.objectid import ObjectId

# CRUD operations for Animal collection in MongoDB
class AnimalShelter(object):
    
    # Initialize the MongoClient and access the hard-coded database with a hard-coded user account
    def __init__(self, username, password):
        USER = username
        PASS = password
        HOST = "nv-desktop-services.apporto.com"
        PORT = 34089
        DB = "AAC"
        COL = "animals"
        
        # Initialize connection
        self.client = MongoClient("mongodb://%s:%s@%s:%d" % (USER, PASS, HOST, PORT))
        self.database = self.client["%s" % (DB)]
        self.collection = self.database["%s" % (COL)]
    
    # Create a document into a specified database and collection
    # Returns true if a document was inserted or false otherwise
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)
            return True
        else:
            return False
    
    # Query for documents from a specified database and collection
    # Returns a list of documents if the query was successfull and an empty list otherwise
    def read(self, query):
        result = []
        
        # Needs a for loop to run through the query results
        for document in self.database.animals.find(query):
            result.append(document)
                
        return result
    
    # Update all documents that match the query with the given data
    # Returns the number of documents updated
    def update(self, query, data):
        return self.database.animals.update_many(query, data).modified_count
    
    # Delete all documents that match the query
    # Returns the number of documents deleted
    def delete(self, query):
        return self.database.animals.delete_many(query).deleted_count

